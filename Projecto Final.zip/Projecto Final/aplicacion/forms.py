from django import forms

class universidadeForm(forms.Form):

    nombre = forms.CharField(label="Nombre de la universidad", max_length=50, required=True)
    ciudad = forms.CharField(label="Ciudad", required=True)

class CiudadMex(forms.Form):

    nombre = forms.CharField(label="Nombre de la universidad", max_length=50, required=True)