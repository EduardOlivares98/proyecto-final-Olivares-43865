from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from .forms import *
from django.views.generic import ListView
from django.views.generic import CreateView
from django.urls import reverse_lazy


# Create your views here.

def index(request):
    return render(request, "aplicacion/base.html")


def buscar_universidades(request):
    ciudad = request.GET.get('categoria1')
    nivel = request.GET.get('categoria2')
    sector = request.GET.get('categoria3')
    modalidad = request.GET.get('categoria4')

    # Realiza las consultas en la base de datos para filtrar las universidades
    universidades_filtradas = nombre.objects.filter(
        ciudad=ciudad, nivel=nivel, sector=sector, modalidad=modalidad
    )

    return render(request, 'aplicacion/buscador.html', {'universidades_filtradas': universidades_filtradas})




def CiudadMexico(request):
    universidades_cdmx = nombre.objects.filter(ciudad='Ciudad de Mexico')
    ctx = {"nombres": universidades_cdmx}
    return render(request, "aplicacion/CiudadMexico.html", ctx)

def updateCiudadMexico(request, id_universidad):
    universidad = nombre.objects.get(id)
    if request.method == "POST":
        miform = CiudadMex(request.POST)
        if miform.is_valid():
            universidad.ciudad = miform.cleaned_data.get("ciudad")
            universidad.save()
            return redirect(reverse_lazy('CiudadMexico'))
    else:
        miform = CiudadMex(initial={'ciudad': universidad.ciudad})
    return render(request, "aplicacion/universidadMex.html", {"form": miform})

def Mexico(request):
    ctx = {"nombres": nombre.objects.all()}
    return render(request, "aplicacion/Mexico.html", ctx)

def NuevoLeon(request):
    universidades_NuevoLeon = nombre.objects.filter(ciudad='Nuevo Leon')
    ctx = {"nombres": universidades_NuevoLeon}
    return render(request, "aplicacion/NuevoLeon.html", ctx)

def Jalisco(request):
    universidades_Jalisco = nombre.objects.filter(ciudad='Jalisco')
    ctx = {"nombres": universidades_Jalisco}
    return render(request, "aplicacion/Jalisco.html", ctx)


def universidadForm(request):
    if request.method == "POST":
        miForm = universidadeForm(request.POST)
        print(miForm)
        if miForm.is_valid:
            informacion = miForm.cleaned_data
            universidad = nombre(nombre=informacion['nombre'], ciudad=informacion['ciudad'])
            universidad.save
            return render(request, "aplicacion/basehtml")
    else:
        miForm = universidadeForm()
    return render(request, "aplicacion/universidadForm.html", {"form": miForm})


class Nombrelist(ListView):
    model = nombre

class NombreCreate(CreateView):
    model = nombre
    fields = ['nombreUniversidad']
    success_url = reverse_lazy('nombres')