from django.urls import path, include
from .views import *
from . import views

urlpatterns = [
    path('', index, name="inicio"),
    path('buscar_universidades/', views.buscar_universidades, name='buscar_universidades'),
    path('CiudadMexico', CiudadMexico, name='CiudadMexico'),
    path('Mexico/', Mexico, name='Mexico'),
    path('NuevoLeon/', NuevoLeon, name='NuevoLeon'),
    path('Jalisco/', Jalisco, name='Jalisco'),
    path('universidadForm/', universidadForm, name='universidadForm'),

    path('nombres/', Nombrelist.as_view(), name='nombres'),
    path('nombres1/', NombreCreate.as_view(), name='nombres1'),
]
