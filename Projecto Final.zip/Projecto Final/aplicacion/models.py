from django.db import models

# Create your models here.

class nombre(models.Model):
    nombreUniversidad = models.CharField(max_length=50)
    
    CIUDADES = [
        ("Nuevo Leon", "Nuevo Leon"),
        ("Jalisco", "Jalisco"),
        ("Ciudad de Mexico", "Ciudad de Mexico"),
    ]
    ciudad = models.CharField(max_length=20, choices=CIUDADES)

    nombreCarreras = models.CharField(max_length=30)

    Modalidades = [
            ("Presencial", "Presencial"),
            ("Virtual", "Virtual"),
            ("Semipresencial", "Semipresencial"),
        ]
    modalidad = models.CharField(max_length=30, choices=Modalidades)

    Sectores = [
                ("Publico", "Publico"),
                ("Privado", "Privado"),
            ]
    sector = models.CharField(max_length=30, choices=Sectores)

    Niveles = [
                ("Licenciatura", "Licenciatura"),
                ("Maestria", "Maestria"),
                ("Doctorado", "Doctorado"),
            ]
    nivel = models.CharField(max_length=30, choices=Niveles)

    def __str__(self):
        return f"{self.nombreUniversidad}"
    

class universidad(models.Model):
    nombreCarreras = models.ManyToManyField(nombre)
    semestres = models.IntegerField()
    descripcion = models.CharField(max_length=250)

    def __str__(self):
        return f"{self.nombreCarreras}"
    